import java.util.*;
public class Vowelconsonant
  {
       public static void main(String arr[])
    {
        char ch = 'i';
      if(ch == 'a' || ch == 'e' || ch == 'i' || ch == 'o' || ch == 'u')
        System.out.println(ch + " is vowel");
      else  
        System.out.println(ch + " is consonant");
    }
  }